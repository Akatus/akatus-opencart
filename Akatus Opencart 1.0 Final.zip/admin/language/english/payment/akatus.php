<?php
// Heading
$_['heading_title']       = 'Akatus - Cartões Crédito';
$_['heading_description'] = 'Configuração para pagamentos com cartão de crédito Akatus.';
// Text
$_['text_akatus'] = '<a onclick="window.open(\'http://www.andresa.com.br\');"><img src="view/image/payment/akatus.gif" alt="Andresa Web Studio" title="Andresa Web Studio" style="border: 1px solid #EEEEEE;" /></a>';
?>