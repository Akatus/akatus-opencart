<?php
// Heading
$_['heading_title']       = 'Akatus - Boleto Bancário';
$_['heading_description'] = 'Configuração para pagamentos com Boleto Bancario através do gateway de pagamentos Akatus.';
// Text
$_['text_akatusb'] = '<a onclick="window.open(\'http://www.andresa.com.br\');"><img src="view/image/payment/akatusb.gif" alt="Andresa Web Studio" title="Andresa Web Studio" style="border: 1px solid #EEEEEE;" /></a>';
?>