

$(document).ready(function () {
			 $("input[name='telephone']").mask("(99)9999-9999?9");
		});
		
