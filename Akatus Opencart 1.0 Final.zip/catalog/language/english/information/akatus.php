﻿<?php
// Heading
$_['heading_title']  = 'Página Akatus'; 
?>