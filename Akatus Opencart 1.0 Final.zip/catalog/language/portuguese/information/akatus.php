﻿<?php
// Heading
$_['heading_title']  = 'Static Page'; //Add as many as you want, but remember to call for it in the controller file before you can use it in the template
?>